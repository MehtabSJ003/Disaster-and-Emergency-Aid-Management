#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <fstream>
#include <cstring>
#include "Perishable.h"
#include "Utils.h"
using namespace std;
namespace sdds {
	Perishable::Perishable() {
		m_handlingInstructions = nullptr;
	}
	Perishable::Perishable(const Perishable& src) :Item(src) {
		m_expiry = src.m_expiry;
		if (src.m_handlingInstructions != nullptr)
		{
			m_handlingInstructions = new char[strlen(src.m_handlingInstructions) + 1];
			strcpy(m_handlingInstructions, src.m_handlingInstructions);
		}
		else
		{
			m_handlingInstructions = nullptr;
		}
	}
	Perishable& Perishable::operator=(const Perishable& src) {
		if (this != &src)
		{
			m_expiry = src.m_expiry;
			delete[] m_handlingInstructions;
			Item::operator=(src);
			if (src.m_handlingInstructions != nullptr)
			{
				m_handlingInstructions = new char[strlen(src.m_handlingInstructions) + 1];
				strcpy(m_handlingInstructions, src.m_handlingInstructions);
			}
			else
			{
				m_handlingInstructions = nullptr;
			}
		}
		return *this;
	}
	Perishable::~Perishable() {
		delete[] m_handlingInstructions;
		m_handlingInstructions = nullptr;
	}
	const Date& Perishable::expiry() {
		return m_expiry;
	}
	int Perishable::readSku(std::istream& istr) {
		m_SKU = ut.getint(10000, 39999, "SKU: ", "Invalid Integer");
		return m_SKU;
	}
	std::ofstream& Perishable::save(std::ofstream& ofstr) const {
		Date d = m_expiry;
		d.formatted(false);
		if (m_state)
		{
			Item::save(ofstr);
			ofstr << "\t";
			if (m_handlingInstructions != nullptr && strlen(m_handlingInstructions)>0)
			{
				ofstr << m_handlingInstructions;
			}
			ofstr << "\t";
			d.write(ofstr);
		}
		return ofstr;
	}
	std::ifstream& Perishable::load(std::ifstream& ifstr) {
		char handlingInstructions[100 + 1];	
		delete[] m_handlingInstructions;
		m_handlingInstructions=nullptr;
		if (ifstr.peek() != EOF)
		{
			Item::load(ifstr);
			ifstr.ignore(2000, '\t');
			ifstr.getline(handlingInstructions, 100 + 1,'\t');
			m_handlingInstructions = new char[strlen(handlingInstructions) + 1];
			strcpy(m_handlingInstructions, handlingInstructions);
			m_expiry.read(ifstr);
			ifstr.ignore();
			if (ifstr.fail())
			{
				m_state = "Input file stream read (perishable) failed!";
			}
		}
		else
		{
			ifstr.ignore(1);
		}
		return ifstr;
	}
	std::ostream& Perishable::display(std::ostream& ostr) const {
		Date d = m_expiry;
		d.formatted(true);
		if (m_SKU > 0)
		{
			if (m_state)
			{
				if (Item::linear())
				{
					Item::display(ostr);
					if (m_handlingInstructions != nullptr && strlen(m_handlingInstructions) > 0)
					{
						ostr << "*";
					}
					else
					{
						ostr << ' ';
					}
					m_expiry.write(ostr);
				}
				else
				{
					ostr << "Perishable ";
					Item::display(ostr);
					ostr << "Expiry date: ";
					d.write(ostr);
					ostr << endl;
					if (m_handlingInstructions != nullptr && strlen(m_handlingInstructions) > 0)
					{
						ostr << "Handling Instructions: " << m_handlingInstructions << endl;
					}
				}
			}
			else
			{
				ostr << m_state;
			}
		}
		return ostr;
	}
	std::istream& Perishable::read(std::istream& istr) {
		char handlingInstructions[100 + 1];
		Item::read(istr);
		delete[] m_handlingInstructions;
		m_handlingInstructions = nullptr;
		cout << "Expiry date (YYMMDD): ";
		m_expiry.read(istr);
		istr.ignore(2000, '\n');
		cout << "Handling Instructions, ENTER to skip: ";
		if (istr.peek() != '\n')
		{
			istr.getline(handlingInstructions, 100 + 1);
			m_handlingInstructions = new char[strlen(handlingInstructions) + 1];
			strcpy(m_handlingInstructions, handlingInstructions);
		}
		if (istr.fail())
		{
			m_state = "Perishable console date entry failed!";
		}
		return istr;
	}
}